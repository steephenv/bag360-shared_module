async function bootstrap() {
  console.log("SharedModule started")
}
bootstrap();
